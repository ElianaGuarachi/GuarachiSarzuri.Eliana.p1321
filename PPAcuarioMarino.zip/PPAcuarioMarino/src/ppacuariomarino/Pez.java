package ppacuariomarino;

public class Pez extends EspecieMarina implements Movible {
    
    private final int longitud;

    public Pez(String nombre, String ubicacion, TipoDeAgua tipo, int longitud) {
        super(nombre, ubicacion, tipo);
        validacionLongitud(longitud);
        this.longitud = longitud;
    }
    
    private void validacionLongitud(int longitud){
        if (longitud <= 0) {
            throw new IllegalArgumentException("La longitud debe ser positiva y distinto de 0");
        }
    }

    @Override
    public String toString() {
        return "Pez{" + super.toString() + ", longitud=" + longitud + '}';
    }

    @Override
    public void reproducir() {
        System.out.println("Soy un Pez y me puedo reproducir " + getNombre());
    }

    @Override
    public void respirar() {
        System.out.println("Soy un Pez y puedo respirar " + getNombre());
    }

    @Override
    public void alimentar() {
        System.out.println("Soy un Pez y me puedo alimentar " + getNombre());
    }

    @Override
    public void mover() {
        System.out.println("Soy un Pez y me puedo mover " + getNombre());
    }
    
}
