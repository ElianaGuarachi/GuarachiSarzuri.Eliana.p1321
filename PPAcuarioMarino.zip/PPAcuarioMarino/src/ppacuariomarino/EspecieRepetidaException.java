package ppacuariomarino;

public class EspecieRepetidaException extends RuntimeException {
    
    private static final String MENSAJE = "Especie repetida";

    public EspecieRepetidaException() {
        this (MENSAJE);
    }

    public EspecieRepetidaException(String message) {
        super(message);
    }
    
}
