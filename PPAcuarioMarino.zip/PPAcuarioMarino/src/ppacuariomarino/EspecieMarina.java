package ppacuariomarino;

import java.util.Objects;

public abstract class EspecieMarina {
    
    private String nombre;
    private String ubicacion;
    private TipoDeAgua tipo;

    public EspecieMarina(String nombre, String ubicacion, TipoDeAgua tipo) {
        this.nombre = nombre;
        this.ubicacion = ubicacion;
        this.tipo = tipo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    public boolean esTipoDeAgua(TipoDeAgua tipo){
        return this.tipo == tipo;
    }

    @Override
    public int hashCode() {
        return Objects.hash(nombre, ubicacion);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final EspecieMarina other = (EspecieMarina) obj;
        if (!Objects.equals(this.nombre, other.nombre)) {
            return false;
        }
        if (!Objects.equals(this.ubicacion, other.ubicacion)) {
            return false;
        }
        return this.tipo == other.tipo;
    }



    @Override
    public String toString() {
        return "EspecieMarina{" + "nombre=" + nombre + ", ubicacion=" + ubicacion + ", tipo=" + tipo + '}';
    }
    
    public abstract void reproducir();
    
    public abstract void respirar();
    
    public abstract void alimentar();
    
}
