package ppacuariomarino;

public class Molusco extends EspecieMarina implements Movible {
        
    private final String tipoDeConcha;

    public Molusco(String nombre, String ubicacion, TipoDeAgua tipo, String tipoDeConcha) {
        super(nombre, ubicacion, tipo);
        this.tipoDeConcha = tipoDeConcha;
    }

    @Override
    public String toString() {
        return "Molusco{" + super.toString() + ", tipoDeConcha=" + tipoDeConcha + '}';
    }

    @Override
    public void reproducir() {
        System.out.println("Soy un Molusco y me puedo reproducir " + getNombre());
    }

    @Override
    public void respirar() {
        System.out.println("Soy un Molusco y puedo respirar " + getNombre());
    }

    @Override
    public void alimentar() {
        System.out.println("Soy un Molusco y me puedo alimentar " + getNombre());
    }

    @Override
    public void mover() {
        System.out.println("Soy un Molusco y me puedo mover " + getNombre());
    }
}
