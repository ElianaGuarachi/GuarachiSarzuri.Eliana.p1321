package ppacuariomarino;

public enum TipoDeAgua {
    SALADA,
    DULCE
}
