package ppacuariomarino;

import java.util.ArrayList;
import java.util.List;

public class AcuarioMarino {
    
    private List<EspecieMarina> especies;

    public AcuarioMarino() {
        this.especies = new ArrayList<>();
    }
    
    public void agregarEspecie(EspecieMarina especie){
        if (especies.contains(especie)) {
            throw new EspecieRepetidaException();
        } else {
            especies.add(especie);
        }
    }
    
    public void mostrarEspecies(){
        for (EspecieMarina especie : especies) {
            System.out.println(especie);
        }
    }
    
    public void moverEspecies() {
        for (EspecieMarina especie : especies) {
            if (especie instanceof Movible m) {
                m.mover();
            } else {
                System.out.println(especie.getNombre() + " no puede moverse");
            }
        }
    }
    
    public void realizarFuncionesBiologicas(){
        for (EspecieMarina especie : especies) {
            especie.alimentar();
            especie.respirar();
        }
    }
    
    public List<EspecieMarina> filtrarPorTipoAgua(TipoDeAgua tipo){
        List<EspecieMarina> filtrados = new ArrayList<>();
        for (EspecieMarina especie : especies) {
            if (especie.esTipoDeAgua(tipo)) {
                filtrados.add(especie);
            }
        }
        return filtrados;
    }
    
    
}
