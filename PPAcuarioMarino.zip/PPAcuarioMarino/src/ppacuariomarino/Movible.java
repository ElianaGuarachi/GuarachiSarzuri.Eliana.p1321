package ppacuariomarino;

public interface Movible {
    
    void mover();
    
}
