package ppacuariomarino;

public class Coral extends EspecieMarina {
        
    private final int profundidad;

    public Coral(String nombre, String ubicacion, TipoDeAgua tipo, int profundidad) {
        super(nombre, ubicacion, tipo);
        validacionProfundidad(profundidad);
        this.profundidad = profundidad;
    }
    
    private void validacionProfundidad(int profundidad){
        if (profundidad <= 0) {
            throw new IllegalArgumentException("La profundidad debe ser positiva y distinto de 0");
        }
    }

    @Override
    public String toString() {
        return "Coral{" + super.toString()  + ", profundidad=" + profundidad + '}';
    }

    @Override
    public void reproducir() {
        System.out.println("Soy un Coral y me puedo reproducir " + getNombre());
    }

    @Override
    public void respirar() {
        System.out.println("Soy un Coral y puedo respirar " + getNombre());
    }

    @Override
    public void alimentar() {
        System.out.println("Soy un Coral y me puedo alimentar " + getNombre());
    }
}
