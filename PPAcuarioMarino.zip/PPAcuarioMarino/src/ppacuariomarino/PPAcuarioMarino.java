package ppacuariomarino;

import java.util.Iterator;

public class PPAcuarioMarino {

    public static void main(String[] args) {
        
        AcuarioMarino acuario = new AcuarioMarino();
        
        cargarEspecies(acuario);
        
        acuario.mostrarEspecies();
        
        System.out.println("******************************************");
        
        acuario.moverEspecies();
        acuario.realizarFuncionesBiologicas();
        
        System.out.println("******************************************");
        
        Iterator<EspecieMarina> it = acuario.filtrarPorTipoAgua(TipoDeAgua.DULCE).iterator();
        while(it.hasNext()){
            System.out.println(it.next());
        }

    }
    
    public static void cargarEspecies(AcuarioMarino acuario){
        try {
            acuario.agregarEspecie(new Pez("Pez 1", "Tanque 1", TipoDeAgua.DULCE, 2));
            acuario.agregarEspecie(new Pez("Pez 2", "Tanque 2", TipoDeAgua.SALADA, 5));
            acuario.agregarEspecie(new Coral("Coral 1", "Tanque 1", TipoDeAgua.DULCE, 7));
            acuario.agregarEspecie(new Molusco("Molusco 1", "Tanque 3", TipoDeAgua.DULCE, "Extra"));
            
        } catch (EspecieRepetidaException e) {
            System.out.println(e.getMessage());
        }
    }
    
}
