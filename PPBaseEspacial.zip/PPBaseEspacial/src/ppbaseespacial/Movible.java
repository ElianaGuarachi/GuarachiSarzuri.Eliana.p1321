package ppbaseespacial;

public interface Movible {
    
    void mover();
    
}
