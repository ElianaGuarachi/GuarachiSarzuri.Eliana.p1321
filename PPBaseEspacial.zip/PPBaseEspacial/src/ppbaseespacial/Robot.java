package ppbaseespacial;

public class Robot extends UnidadOperativa implements Movible {
    
    private final int autonomia;

    public Robot(String nombre, String modulo, TipoAtmosfera tipo, int autonomia) {
        super(nombre, modulo, tipo);
        validarAutonomia(autonomia);
        this.autonomia = autonomia;
    }
    
    private void validarAutonomia(int autonomia){
        if (autonomia <= 0) {
            throw new IllegalArgumentException("La autonomia no puede ser negativas");
        }
    }

    @Override
    public String toString() {
        return "Robot{" + "autonomia=" + autonomia + '}';
    }

    @Override
    public void reabastecerse() {
        System.out.println("Soy un robot y me reabastezco" + getNombre());
    }

    @Override
    public void mantenerCondiciones() {
        System.out.println("Soy un robot y mantengo condiciones" + getNombre());
    }

    @Override
    public void replicarse() {
        System.out.println("Soy un robot y me replico" + getNombre());
    }

    @Override
    public void mover() {
        System.out.println("Soy un robot y me muevo" + getNombre());
    }
    
}
