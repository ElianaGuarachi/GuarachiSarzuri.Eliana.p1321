package ppbaseespacial;

public abstract class UnidadOperativa {
    
    private final String nombre;
    private final String modulo;
    private final TipoAtmosfera tipo;

    public UnidadOperativa(String nombre, String modulo, TipoAtmosfera tipo) {
        this.nombre = nombre;
        this.modulo = modulo;
        this.tipo = tipo;
    }

    public String getNombre() {
        return nombre;
    }

    public String getModulo() {
        return modulo;
    }

    public TipoAtmosfera getTipo() {
        return tipo;
    }
    
    public boolean esTipo(TipoAtmosfera tipo){
        return this.tipo == tipo;
    }

    @Override
    public String toString() {
        return "UnidadOperativa{" + "nombre=" + nombre + ", modulo=" + modulo + ", tipo=" + tipo + '}';
    }
    
    public abstract void reabastecerse();
    
    public abstract void mantenerCondiciones();
    
    public abstract void replicarse();
    
}
