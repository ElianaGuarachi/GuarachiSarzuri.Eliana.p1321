
package ppbaseespacial;

public class Experimento extends UnidadOperativa implements Movible {
    
    private final int duracionIdeal;

    public Experimento(String nombre, String modulo, TipoAtmosfera tipo, int duracionIdeal) {
        super(nombre, modulo, tipo);
        validarDuracionIdeal(duracionIdeal);
        this.duracionIdeal = duracionIdeal;
    }
    
    private void validarDuracionIdeal(int duracionIdeal){
        if (duracionIdeal <= 0) {
            throw new IllegalArgumentException("La duracion ideal no pueden ser negativas");
        }
    }

    @Override
    public String toString() {
        return "Experimento{" + "duracionIdeal=" + duracionIdeal + '}';
    }

    @Override
    public void reabastecerse() {
        System.out.println("Soy un experimento y me reabastezco" + getNombre());
    }

    @Override
    public void mantenerCondiciones() {
        System.out.println("Soy un experimento y mantengo condiciones" + getNombre());
    }

    @Override
    public void replicarse() {
        System.out.println("Soy un experimento y me replico" + getNombre());
    }

    @Override
    public void mover() {
        System.out.println("Soy un experimento y me muevo" + getNombre());
    }
}
