package ppbaseespacial;

public class UnidadRepetidaException extends RuntimeException {
    
    private static final String MENSAJE = "Base espacial repetida";

    public UnidadRepetidaException() {
        this (MENSAJE);
    }

    public UnidadRepetidaException (String message) {
        super(message);
    }
}
