package ppbaseespacial;

import java.util.Iterator;

public class PPBaseEspacial {

    public static void main(String[] args) {
        
        BaseEspacial base = new BaseEspacial();
        
        cargarBases(base);
        
        base.mostrarUnidades();
        
        System.out.println("******************************************");
        
        base.moverUnidades();
        base.realizarFuncionesBase();
        
        System.out.println("******************************************");
        
        Iterator<UnidadOperativa> it = base.filtrarPorTipoAtmosfera(TipoAtmosfera.PRESURIZADA).iterator();
        while(it.hasNext()){
            System.out.println(it.next());
        }

    }
    
    public static void cargarBases(BaseEspacial base){
        try {
            base.agregarUnidadOperativa(new Astronauta("Nombre 1", "Modulo 1", TipoAtmosfera.PRESURIZADA, 14));
            base.agregarUnidadOperativa(new Experimento("Nombre 3", "Modulo 1", TipoAtmosfera.PRESURIZADA,45));
            base.agregarUnidadOperativa(new Robot("Nombre 4", "Modulo 4", TipoAtmosfera.PRESURIZADA, 4));
            base.agregarUnidadOperativa(new Experimento("Nombre 5", "Modulo 5", TipoAtmosfera.PRESURIZADA, 25));
            base.agregarUnidadOperativa(new Astronauta("Nombre 2", "Modulo 2", TipoAtmosfera.VACIO, 10));
            
        } catch (UnidadRepetidaException e) {
            System.out.println(e.getMessage());
        }
    }
    
}
