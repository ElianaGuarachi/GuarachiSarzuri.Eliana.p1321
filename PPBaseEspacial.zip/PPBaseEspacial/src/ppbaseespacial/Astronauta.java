package ppbaseespacial;

public class Astronauta extends UnidadOperativa implements Movible {
    
    private final int horasEva;

    public Astronauta(String nombre, String modulo, TipoAtmosfera tipo, int horasEva) {
        super(nombre, modulo, tipo);
        validarHorasEva(horasEva);
        this.horasEva = horasEva;
    }
    
    private void validarHorasEva(int horas){
        if (horas <= 0) {
            throw new IllegalArgumentException("Las horas no pueden ser negativas");
        }
    }

    @Override
    public String toString() {
        return "Astronauta{" + "horasEva=" + horasEva + '}';
    }

    @Override
    public void reabastecerse() {
        System.out.println("Soy un astronauta y me reabastezco" + getNombre());
    }

    @Override
    public void mantenerCondiciones() {
        System.out.println("Soy un astronauta y mantengo condiciones" + getNombre());
    }

    @Override
    public void replicarse() {
        System.out.println("Soy un astronauta y me replico" + getNombre());
    }

    @Override
    public void mover() {
        System.out.println("Soy un astronauta y me muevo" + getNombre());
    }
    
}
