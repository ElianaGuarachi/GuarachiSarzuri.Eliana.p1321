package ppbaseespacial;

import java.util.ArrayList;
import java.util.List;

public class BaseEspacial {
    
    private List<UnidadOperativa> unidades = new ArrayList<>();
    
    public void agregarUnidadOperativa(UnidadOperativa unidad){
        if (unidades.contains(unidad)) {
            throw new UnidadRepetidaException();
        } else {
            unidades.add(unidad);
        }
    }
    
    public void mostrarUnidades(){
        for (UnidadOperativa unidad : unidades) {
            System.out.println(unidad);
        }
    }
    
    public void moverUnidades(){
        for (UnidadOperativa unidad : unidades) {
            if (unidad instanceof Movible m) {
                m.mover();
            } else {
                System.out.println(unidad.getNombre() + " no puede moverse");
            }
        }
    }
    
    public void realizarFuncionesBase(){
        for (UnidadOperativa unidad : unidades) {
            unidad.reabastecerse();
            unidad.replicarse();
        }
    }
    
    public List<UnidadOperativa> filtrarPorTipoAtmosfera(TipoAtmosfera tipo){
        List<UnidadOperativa> filtrado = new ArrayList<>();
        for (UnidadOperativa unidad : unidades) {
            if (unidad.esTipo(tipo)) {
                filtrado.add(unidad);
            }
        }
        return filtrado;
    }
}
