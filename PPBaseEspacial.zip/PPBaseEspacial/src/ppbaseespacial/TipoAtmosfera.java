package ppbaseespacial;

public enum TipoAtmosfera {
    PRESURIZADA,
    VACIO
}
